def EditDistBU(A,B):
    

#1653264 3918848

#3918848 1653264
#3918848 % 1653264
def main():
    a, b = map(int, input().split())
    print(computeGCD(a, b))
    #print(gcd(a, b))

if __name__ == "__main__":
    main()