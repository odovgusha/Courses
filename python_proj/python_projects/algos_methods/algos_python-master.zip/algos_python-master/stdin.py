import sys
stdin = input("Enter your name: ")
stdin = stdin.split()
setup = list(map(int, stdin))

print(setup)